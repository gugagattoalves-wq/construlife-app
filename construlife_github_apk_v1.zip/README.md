# Construlife Android

Projeto Android nativo da Construlife, com workflow pronto para gerar APK pelo GitHub Actions.

## Como gerar o APK pelo celular
1. Crie um repositório novo no GitHub.
2. Envie todos os arquivos e pastas deste ZIP.
3. No GitHub, abra **Actions**.
4. Selecione **Construir APK Construlife**.
5. Toque em **Run workflow**.
6. Ao terminar, abra a execução e baixe o artefato **Construlife-apk**.

O workflow usa Java 17 + Gradle 8.10.2 para evitar o conflito Java/Gradle que ocorreu no compilador anterior.

Antes da publicação final, ainda vamos colocar o número real do WhatsApp, fotos, serviços e os dados da Construlife.
