package com.construlife.app;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(244,246,248));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(28));

        ImageView logo = new ImageView(this);
        logo.setImageResource(com.construlife.app.R.drawable.construlife_logo);
        logo.setAdjustViewBounds(true);
        root.addView(logo, new LinearLayout.LayoutParams(-1, dp(210)));

        TextView title = new TextView(this);
        title.setText("Construlife");
        title.setTextSize(28);
        title.setTextColor(Color.rgb(18,51,74));
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, 1);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Construção • Reformas • Elétrica • Hidráulica • Manutenção");
        subtitle.setTextSize(15);
        subtitle.setTextColor(Color.DKGRAY);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, dp(4), 0, dp(18));
        root.addView(subtitle);

        addButton(root, "🔧  Nossos serviços", v ->
            Toast.makeText(this, "Serviços: elétrica, hidráulica, reformas, impermeabilização e manutenção.", Toast.LENGTH_LONG).show());

        addButton(root, "💰  Solicitar orçamento", v ->
            Toast.makeText(this, "Em breve: formulário para solicitar orçamento e enviar fotos.", Toast.LENGTH_LONG).show());

        addButton(root, "🚨  Atendimento emergencial", v ->
            Toast.makeText(this, "Em breve: botão de emergência ligado ao WhatsApp da Construlife.", Toast.LENGTH_LONG).show());

        addButton(root, "📸  Enviar fotos do serviço", v ->
            Toast.makeText(this, "Em breve: envio de fotos diretamente pelo aplicativo.", Toast.LENGTH_LONG).show());

        addButton(root, "📞  Falar com a Construlife", v -> {
            try {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/55"));
                startActivity(i);
            } catch (Exception e) {
                Toast.makeText(this, "WhatsApp ainda precisa do número da Construlife.", Toast.LENGTH_LONG).show();
            }
        });

        TextView footer = new TextView(this);
        footer.setText("Construlife • Atendimento profissional");
        footer.setGravity(Gravity.CENTER);
        footer.setTextColor(Color.GRAY);
        footer.setPadding(0, dp(22), 0, 0);
        root.addView(footer);

        scroll.addView(root);
        setContentView(scroll);
    }

    private void addButton(LinearLayout root, String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(16);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(Color.rgb(47,109,246));
        b.setOnClickListener(listener);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(54));
        p.setMargins(0, 0, 0, dp(12));
        root.addView(b, p);
    }
}
